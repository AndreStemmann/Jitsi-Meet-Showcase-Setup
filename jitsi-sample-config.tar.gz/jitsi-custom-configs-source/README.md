# Sample Jitsi-Meet Config

The following Jitsi-Meet sample-setup is capable of managing around 35 Users per
Conference on old hardware, depending on your bandwidth.
Furthermore it's running on a different port 8443, has an authentification and a
working Etherpad.

## Installation
Adapt the configs to your needs, it's just a showcase for common questions from
the Jitsi Userspace of how to on another port, howto auth and howto etherpad
and howto on old hardware.
